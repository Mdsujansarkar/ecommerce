<?php

$pages = 'product';
include 'index.php';