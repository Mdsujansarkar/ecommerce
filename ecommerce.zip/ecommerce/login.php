<?php

$pages ="login";

include 'index.php';