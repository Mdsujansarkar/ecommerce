<?php 

$pages ='shop';
include 'index.php';