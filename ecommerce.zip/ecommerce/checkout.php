<?php

 $pages = 'checkout';
 include 'index.php';