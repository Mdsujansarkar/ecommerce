<?php 



class Super_admin{

	private $dbconnection;
	public function __construct(){
		$host_name= 'Localhost';
		$user_name ='root';
		$password ='';
		$dbname ='db_shop';
		$this ->dbconnection= mysqli_connect($host_name, $user_name, $password, $dbname);

		if(!$this ->dbconnection){
			die('Conection Fail'. mysqli_error($this ->dbconnection));
		}
	}

    public function save_category_info($data){
    	
    	$sql = "INSERT INTO tbl_category(category_name, category_description, category_status) VALUES('$data[category_name]', '$data[category_description]', '$data[sts]')";
        
        if(mysqli_query($this->dbconnection, $sql)){
        	$message = "category creat successfully";
        	return $message;
        }else{
        	die('query problem'. mysqli_error($this->dbconnection));
        }
    }

    public function select_all_category_info(){
    	$sql = "SELECT * FROM tbl_category";
        
        if(mysqli_query($this->dbconnection, $sql)){
        	$query_result = mysqli_query($this->dbconnection, $sql);

        	return $query_result;
        }else{
        	die('query problem'. mysqli_error($this->dbconnection));
        }
    }
    
    public function unpublished_by_category_id($category_id){
        $sql = "UPDATE tbl_category SET category_status=0 WHERE category_id='$category_id'";
        
        if(mysqli_query($this->dbconnection, $sql)){
            $message = "Category unpublished successfully";
            return $message;

        }else{
            die('query problem'. mysqli_error($this->dbconnection));
        }
    }

    public function published_by_category_id($category_id){
        $sql = "UPDATE tbl_category SET category_status=1 WHERE category_id='$category_id'";
        
        if(mysqli_query($this->dbconnection, $sql)){
            $message = "Category unpublished successfully";
            return $message;

        }else{
            die('query problem'. mysqli_error($this->dbconnection));
        }
    }

    public function delete_by_category_id($category_id){
         $sql = "DELETE FROM tbl_category WHERE category_id='$category_id'";
        
        if(mysqli_query($this->dbconnection, $sql)){
            $message = "Category unpublished successfully";
            return $message;

        }else{
            die('query problem'. mysqli_error($this->dbconnection));
        }
    }
    public function select_category_info_by_category_id($category_id) {
        $sql = "SELECT * FROM tbl_category WHERE category_id='$category_id' ";
        $resource_id = mysqli_query($this->dbconnection, $sql);
        return $resource_id;
    }
    public function update_category_info_by_category_id($data) {
        $sql = "UPDATE tbl_category SET category_name='$data[category_name]', category_description='$data[category_description]', category_status='$data[sts]' WHERE category_id='$data[category_id]'";
        if (mysqli_query($this->dbconnection, $sql)) {
            $_SESSION['message'] = "Category info update sucessfully";
            header('Location:http://localhost/ecommerce/admin/manage_category.php');
        } else {
            die('Query problem' . mysqli_error($this->dbconnection));
        }
    }

    public function save_manufacturer_info($data){
     $sql = "INSERT INTO tbl_manufacture(manufacturer_name, manufacturer_description, manufacturer_status) VALUES('$data[manufacturer_name]', '$data[manufacturer_description]', '$data[sts]')";
        
        if(mysqli_query($this->dbconnection, $sql)){
            $message = "manufacturer creat successfully";
            return $message;
        }else{
            die('query problem'. mysqli_error($this->dbconnection));
        }   
    }
    public function select_all_manufacturer_info(){
        $sql = "SELECT * FROM tbl_manufacture";
        
        if(mysqli_query($this->dbconnection, $sql)){
            $query_result = mysqli_query($this->dbconnection, $sql);

            return $query_result;
        }else{
            die('query problem'. mysqli_error($this->dbconnection));
        }

    }

    public function unpublished_by_manufacturer_id($manufacturer_id){
    
       $sql = "UPDATE tbl_manufacture SET manufacturer_status=0 WHERE manufacturer_id='$manufacturer_id'";
        
        if(mysqli_query($this->dbconnection, $sql)){
            $message = "manufacturer unpublished successfully";
            return $message;

        }else{
            die('query problem'. mysqli_error($this->dbconnection));
        }

    }

    public function published_by_manufacturer_id($manufacturer_id){
         $sql = "UPDATE tbl_manufacture SET manufacturer_status=1 WHERE manufacturer_id='$manufacturer_id'";
        
        if(mysqli_query($this->dbconnection, $sql)){
            $message = "manufacturer published successfully";
            return $message;

        }else{
            die('query problem'. mysqli_error($this->dbconnection));
        }
    }
    public function select_manufacturer_info_by_id($manufacturer_id){
       $sql = "SELECT * FROM tbl_manufacture WHERE manufacturer_id = '$manufacturer_id'";
        
        if(mysqli_query($this->dbconnection, $sql)){
            $query_result = mysqli_query($this->dbconnection, $sql);

            return $query_result;
        }else{
            die('query problem'. mysqli_error($this->dbconnection));
        }

    }
    public function update_manufacturer_info($data){
        $sql = "UPDATE tbl_manufacture SET manufacturer_name='$data[manufacturer_name]', manufacturer_description='$data[manufacturer_description]', manufacturer_status='$data[sts]' WHERE manufacturer_id='$data[manufacturer_id]'";
        if (mysqli_query($this->dbconnection, $sql)) {
            $_SESSION['message'] = "manufacturer info update sucessfully";
            header('Location:http://localhost/ecommerce/admin/manage_menufacture.php');
        } else {
            die('Query problem' . mysqli_error($this->dbconnection));
        }
    }






	public function logout(){
		unset($_SESSION['admin_name']);
		unset($_SESSION['admin_id']);
		header('Location: index.php');
	}
}