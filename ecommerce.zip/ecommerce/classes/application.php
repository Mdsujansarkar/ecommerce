<?php 


class Application{
	private $dbconnection;
	public function __construct(){
		$host_name= 'Localhost';
		$user_name ='root';
		$password ='';
		$dbname ='db_shop';
		$this ->dbconnection= mysqli_connect($host_name, $user_name, $password, $dbname);

		if(!$this ->dbconnection){
			die('Conection Fail'. mysqli_error($this ->dbconnection));
		}
	}

	public function select_all_published_category(){
		$sql = "SELECT * FROM tbl_category WHERE category_status= 1";
		if(mysqli_query($this->dbconnection, $sql)){
			$query_result = mysqli_query($this->dbconnection, $sql);
			return $query_result; 
		}else{
			die("Query problem". mysqli_error($this->dbconnection));
		}
	} 
	public function select_all_published_manufacture(){
			$sql = "SELECT * FROM tbl_manufacture WHERE manufacturer_status= 1";
		if(mysqli_query($this->dbconnection, $sql)){
			$query_result = mysqli_query($this->dbconnection, $sql);
			return $query_result; 
		}else{
			die("Query problem". mysqli_error($this->dbconnection));
		}
	}
}