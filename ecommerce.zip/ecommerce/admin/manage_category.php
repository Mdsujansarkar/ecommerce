<?php 
$pages ="manage";
include "admin_master.php";

