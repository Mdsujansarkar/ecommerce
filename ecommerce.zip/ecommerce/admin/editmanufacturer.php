<?php 

$pages = "editmanufacturer";
include "admin_master.php";