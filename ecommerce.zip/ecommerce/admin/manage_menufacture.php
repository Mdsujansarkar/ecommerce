<?php 
$pages ="manage_menufacture";
include "admin_master.php";
