<?php 
$pages ="editcategory";
include "admin_master.php";
