<?php
$pages = "manufacture";
include "admin_master.php";