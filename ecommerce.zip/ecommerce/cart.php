<?php
$pages = 'cart';

include 'index.php';

